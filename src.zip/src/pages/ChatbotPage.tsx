import AuthStatus from "../components/AuthStatus";
import { useEffect, useMemo, useRef, useState } from "react";
import type React from "react";
import { motion } from "framer-motion";
import {
  Brain,
  Loader2,
  ShieldCheck,
  Sparkles,
  SendHorizontal,
  HelpCircle,
  CheckCircle2,
  Lock,
} from "lucide-react";
import { api } from "../lib/api";
import type { Trait } from "../lib/api";

type Msg = {
  id: string;
  role: "assistant" | "user";
  content: string;
  ts: number; // ms since epoch (local)
};

type ChatPhase = "self" | "pref" | "done";

type ServerProgress = {
  self_filled?: number;
  self_total?: number;
  pref_filled?: number;
  pref_total?: number;
};

export default function ChatbotPage() {
  // Chat messages
  const [messages, setMessages] = useState<Msg[]>([
    {
      id: crypto.randomUUID(),
      role: "assistant",
      content:
        "Hi, I’m your LikeMinded guide. We’ll walk through a short, therapist-style assessment together.",
      ts: Date.now(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const isSendingRef = useRef(false); // hard guard against double POST
  const [isTyping, setIsTyping] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [phase, setPhase] = useState<ChatPhase>("self");
  const [serverProgress, setServerProgress] =
    useState<ServerProgress | null>(null);

  // Traits + scores from backend (still used to compute progress, but not shown in a big grid)
  const [traits, setTraits] = useState<Trait[]>([]);
  const [traitsLoading, setTraitsLoading] = useState(true);
  const [traitsError, setTraitsError] =
    useState<string | null>(null);

  // Attribute map: keys like "5" and "attr_05" → score
  const [attributes, setAttributes] = useState<Record<string, number>>({});

  const bottomRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // -------------------- Load traits once --------------------
  useEffect(() => {
    async function loadTraits() {
      setTraitsLoading(true);
      setTraitsError(null);
      try {
        const rows = await api.listPersonalityTraits(); // includes score
        setTraits(rows);

        // Seed attributes map from DB scores
        setAttributes((prev) => {
          const next = { ...prev };
          for (const t of rows) {
            if (t.score == null) continue;
            const idStr = String(t.id);
            const padded = idStr.padStart(2, "0");
            const num =
              typeof t.score === "number"
                ? t.score
                : Number(t.score);
            if (Number.isNaN(num)) continue;
            next[idStr] = num;
            next[`attr_${padded}`] = num;
          }
          return next;
        });
      } catch (e) {
        console.error("Error loading traits", e);
        setTraitsError("Could not load traits.");
      } finally {
        setTraitsLoading(false);
      }
    }

    loadTraits();
  }, []);

  // -------------------- Load persisted chat history --------------------
  useEffect(() => {
    let cancelled = false;

    async function loadHistory() {
      try {
        const data = await api.chatbotHistory();
        if (cancelled) return;

        const histMsgs: Msg[] = (data.messages || []).map(
          (m: any, idx: number) => ({
            id: `hist-${idx}`,
            role: m.role === "assistant" ? "assistant" : "user",
            content: m.content,
            ts: m.ts ? Date.parse(m.ts) : Date.now(),
          })
        );

        // If there is any server history, replace the initial greeting
        if (histMsgs.length > 0) {
          setMessages(histMsgs);
        }

        if (data.phase) {
          setPhase(data.phase as ChatPhase);
        }
        if (data.progress) {
          setServerProgress(data.progress);
        }
      } catch (err) {
        console.error("Failed to load chatbot history", err);
      } finally {
        if (!cancelled) {
          setIsLoadingHistory(false);
        }
      }
    }

    loadHistory();

    return () => {
      cancelled = true;
    };
  }, []);

  // -------------------- Helpers --------------------
  function getAttributeValueForTrait(trait: Trait): number | undefined {
    const idStr = String(trait.id);
    const padded = idStr.padStart(2, "0");

    const candidates = [
      attributes[`attr_${padded}`],
      attributes[`attr_${idStr}`],
      attributes[idStr],
    ];

    for (const v of candidates) {
      if (typeof v === "number" && !Number.isNaN(v)) return v;
    }

    if (trait.score != null) {
      const num =
        typeof trait.score === "number" ? trait.score : Number(trait.score);
      if (!Number.isNaN(num)) return num;
    }

    return undefined;
  }

  const progress = useMemo(() => {
    // Prefer backend-provided counts for self + pref.
    const selfFilled = serverProgress?.self_filled ?? 0;
    const prefFilled = serverProgress?.pref_filled ?? 0;
    const selfTotal = serverProgress?.self_total;
    const prefTotal = selfTotal;

    // If backend is giving us both totals, we can mirror:
    // X = user_personality rows + user_personality_pref rows
    // Y = 2 * personality_traits rows (self_total + pref_total)
    if (selfTotal != null && prefTotal != null) {
      const filled = selfFilled + prefFilled;
      const total = selfTotal + prefTotal;

      return {
        filled,
        total,
        pct: total ? Math.round((filled / total) * 100) : 0,
      };
    }

    // Fallback: only self traits known (old behavior)
    const traitsTotal = traits.length || selfTotal || 20;
    const filledSelf = traits.filter(
      (t) => typeof getAttributeValueForTrait(t) === "number"
    ).length;

    const total = traitsTotal;
    const filled = filledSelf;

    return {
      filled,
      total,
      pct: total ? Math.round((filled / total) * 100) : 0,
    };
  }, [traits, attributes, serverProgress]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, isTyping]);

  function phaseLabel(p: ChatPhase) {
    if (p === "self") return "Mapping your patterns";
    if (p === "pref") return "Understanding your preferences";
    return "Assessment complete";
  }

  // Chatbot reply: apply updated_traits
  async function getReply(userText: string): Promise<string> {
    const res = await api.chatbotMessage(userText);

    if (res.updated_traits) {
      setAttributes((prev) => {
        const next = { ...prev };
        for (const [traitIdStr, raw] of Object.entries(
          res.updated_traits!
        )) {
          const num =
            typeof raw === "number" ? raw : Number(raw as any);
          if (Number.isNaN(num)) continue;
          const idStr = traitIdStr;
          const padded = idStr.padStart(2, "0");
          next[idStr] = num;
          next[`attr_${padded}`] = num;
        }
        return next;
      });
    }

    if (res.phase) {
      setPhase(res.phase as ChatPhase);
    }
    if (res.progress) {
      setServerProgress((prev) => ({
        ...(prev || {}),
        ...res.progress,
      }));
    }

    return res.reply;
  }

  // Core send
  async function sendMessage(contentOverride?: string) {
    const baseContent = contentOverride ?? input.trim();
    if (!baseContent) return;

    if (isSendingRef.current) return; // extra guard
    isSendingRef.current = true;
    setIsSending(true);
    setIsTyping(true);

    const userMsg: Msg = {
      id: crypto.randomUUID(),
      role: "user",
      content: baseContent,
      ts: Date.now(),
    };

    setMessages((m) => [...m, userMsg]);
    setInput("");

    try {
      const reply = await getReply(userMsg.content);
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: reply,
          ts: Date.now(),
        },
      ]);
    } catch (err) {
      console.error(err);
      setMessages((m) => [
        ...m,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: "Network error—try again.",
          ts: Date.now(),
        },
      ]);
    } finally {
      setIsTyping(false);
      setIsSending(false);
      isSendingRef.current = false;
    }
  }

  // Simple renderer: no MCQ parsing, just text
  function renderMessageContent(m: Msg) {
    return <span>{m.content}</span>;
  }

  // -------------------- Render --------------------
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-slate-50">
      {/* Soft background glow */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-24 left-0 right-0 mx-auto h-64 w-64 rounded-full bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.22),_transparent_60%)] blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,_rgba(244,114,182,0.18),_transparent_60%)] blur-3xl" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/75 backdrop-blur dark:border-slate-800/80 dark:bg-slate-950/70">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 shadow-sm shadow-indigo-400/40">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">
                LikeMinded
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Assessment guide
              </span>
            </div>
          </div>

          <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300 md:flex">
            <a href="/" className="hover:text-indigo-600 dark:hover:text-indigo-300">
              Home
            </a>
            <a
              href="/conversations"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Conversations
            </a>
            <a
              href="/profile"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Profile
            </a>
          </nav>

          <div className="hidden items-center gap-2 text-[11px] text-slate-500 sm:flex dark:text-slate-400">
            <ShieldCheck className="h-4 w-4" />
            Verified community
          </div>
        </div>
      </header>

      <main className="mx-auto flex max-w-6xl flex-col gap-6 px-4 pb-12 pt-6 sm:px-6 lg:px-8 lg:flex-row">
        {/* Chat column */}
        <section className="flex-1">
          <div className="flex flex-col gap-3 rounded-3xl border border-slate-200 bg-white/90 shadow-sm shadow-slate-200/60 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/90 dark:shadow-black/40">
            {/* Progress header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-200 px-4 py-3 text-sm dark:border-slate-800 sm:px-5">
              <div className="flex flex-col gap-1">
                <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-indigo-500 dark:text-indigo-300">
                  Assessment progress
                </div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                  {progress.filled} / {progress.total} attributes mapped
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {phaseLabel(phase)}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="relative h-10 w-10">
                  <div className="absolute inset-0 rounded-full bg-slate-100 dark:bg-slate-800" />
                  <div
                    className="absolute inset-[2px] rounded-full bg-[conic-gradient(var(--indigo)_calc(var(--pct)*1%),_transparent_0)]"
                    style={
                      {
                        "--pct": progress.pct / 100,
                        "--indigo": "rgb(129 140 248)",
                      } as React.CSSProperties
                    }
                  />
                  <div className="absolute inset-[6px] rounded-full bg-white text-[11px] font-semibold text-slate-800 grid place-items-center dark:bg-slate-900 dark:text-slate-50">
                    {progress.pct}%
                  </div>
                </div>
              </div>
            </div>

            {/* Thread */}
            <div className="flex h-[60vh] flex-col overflow-hidden">
              <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4 sm:px-5">
                {isLoadingHistory && (
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Loading your previous conversation…</span>
                  </div>
                )}

                {messages.map((m) => (
                  <motion.div
                    key={m.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${
                      m.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                        m.role === "user"
                          ? "bg-indigo-600 text-slate-50 dark:bg-indigo-500"
                          : "bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-slate-50"
                      }`}
                    >
                      {renderMessageContent(m)}
                    </div>
                  </motion.div>
                ))}

                {isTyping && (
                  <div className="flex justify-start">
                    <div className="inline-flex items-center gap-2 rounded-2xl bg-slate-100 px-4 py-3 text-sm text-slate-500 dark:bg-slate-800 dark:text-slate-300">
                      <Loader2 className="h-4 w-4 animate-spin" /> thinking…
                    </div>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>

              {/* Composer */}
              <form
                className="border-t border-slate-200 bg-white/90 px-4 py-3 dark:border-slate-800 dark:bg-slate-900/90 sm:px-5"
                onSubmit={(e) => {
                  e.preventDefault();
                  void sendMessage();
                }}
              >
                <div className="flex items-center gap-3">
                  <input
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your response…"
                    className="flex-1 rounded-2xl border border-slate-300 bg-white/80 px-4 py-2.5 text-sm text-slate-900 outline-none ring-0 transition focus:border-indigo-400 focus:ring-2 focus:ring-indigo-200 dark:border-slate-600 dark:bg-slate-950/60 dark:text-slate-50 dark:focus:border-indigo-400 dark:focus:ring-indigo-500/30"
                  />
                  <button
                    type="submit"
                    disabled={isSending}
                    className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-2.5 text-xs font-semibold text-white shadow-md shadow-indigo-400/30 hover:brightness-110 disabled:opacity-60"
                  >
                    <SendHorizontal className="h-4 w-4" />
                    Send
                  </button>
                </div>
                <div className="mt-1 text-[10px] text-slate-500 dark:text-slate-400">
                  You can stop anytime—your progress stays saved.
                </div>
              </form>
            </div>
          </div>
        </section>

        {/* Right column: overview, tips, safety */}
        <aside className="flex w-full max-w-sm flex-col gap-4 lg:w-80">
          {/* Overview card */}
          <div className="rounded-3xl border border-slate-200 bg-white/90 p-4 text-sm shadow-sm shadow-slate-200/60 dark:border-slate-800 dark:bg-slate-900/90 dark:shadow-black/40">
            <div className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-indigo-500 dark:text-indigo-300" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                What we’re doing here
              </h2>
            </div>
            <p className="mt-2 text-[13px] text-slate-600 dark:text-slate-300">
              This isn’t a quiz. It’s a short, therapist-style conversation that maps how
              you react, recover, and relate so we can match you on emotional fit—not
              just swipes.
            </p>
            <ul className="mt-3 space-y-2 text-[12px] text-slate-600 dark:text-slate-300">
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 text-indigo-500 dark:text-indigo-300" />
                Around 8–10 minutes total, but you can pause and come back.
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 text-indigo-500 dark:text-indigo-300" />
                No “good” or “bad” answers—only patterns we can align with others.
              </li>
              <li className="flex gap-2">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 text-indigo-500 dark:text-indigo-300" />
                Your matches later show up under{" "}
                <a
                  href="/conversations"
                  className="font-medium text-indigo-600 underline underline-offset-2 dark:text-indigo-300"
                >
                  Conversations
                </a>
                .
              </li>
            </ul>
          </div>

          {/* Tips card */}
          <div className="rounded-3xl border border-slate-200 bg-white/90 p-4 text-sm shadow-sm shadow-slate-200/60 dark:border-slate-800 dark:bg-slate-900/90 dark:shadow-black/40">
            <div className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-rose-500 dark:text-rose-300" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                How to answer
              </h2>
            </div>
            <ul className="mt-2 space-y-2 text-[12px] text-slate-600 dark:text-slate-300">
              <li className="flex gap-2">
                <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-400" />
                Use real situations: describe what actually happens when you’re upset,
                excited, or unsure.
              </li>
              <li className="flex gap-2">
                <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-400" />
                If a question feels off, say so. That’s also useful signal.
              </li>
              <li className="flex gap-2">
                <span className="mt-0.5 h-1.5 w-1.5 shrink-0 rounded-full bg-slate-400" />
                Short answers are fine—this is not an essay.
              </li>
            </ul>
          </div>

          {/* Privacy / status card */}
          <div className="rounded-3xl border border-slate-200 bg-white/90 p-4 text-sm shadow-sm shadow-slate-200/60 dark:border-slate-800 dark:bg-slate-900/90 dark:shadow-black/40">
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-emerald-500 dark:text-emerald-300" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                Your data & safety
              </h2>
            </div>
            <p className="mt-2 text-[12px] text-slate-600 dark:text-slate-300">
              Raw chat logs aren’t shown to matches. We use a summarized profile and
              compatibility signals instead.
            </p>
            <p className="mt-2 text-[12px] text-slate-600 dark:text-slate-300">
              Verification media is stored securely and only visible to authorized
              reviewers for safety checks.
            </p>
            {traitsLoading && (
              <p className="mt-2 text-[11px] text-slate-400 dark:text-slate-500">
                Loading your assessment model…
              </p>
            )}
            {traitsError && (
              <p className="mt-2 text-[11px] text-rose-500 dark:text-rose-400">
                {traitsError}
              </p>
            )}
          </div>
        </aside>
      </main>

      <div className="px-4 pb-6 sm:px-6 lg:px-8">
        <AuthStatus />
      </div>
    </div>
  );
}
