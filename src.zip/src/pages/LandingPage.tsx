import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Brain,
  MessageSquareHeart,
  ShieldCheck,
  Sparkles,
  Users2,
  ChevronDown,
  HeartHandshake,
  Moon,
  Sun,
} from "lucide-react";
import { useTheme } from "../theme/ThemeProvider";

type FAQItem = {
  q: string;
  a: string;
};

const faqItems: FAQItem[] = [
  {
    q: "What is LikeMinded?",
    a: "LikeMinded is a compatibility-first dating product. Instead of swiping, you talk to a therapist-style chatbot that helps map your emotional patterns, communication style, and relationship needs.",
  },
  {
    q: "Why do I need an assessment first?",
    a: "We want you to meet people who fit the way you actually think and feel. The assessment gives us a structured view of your patterns, so we can filter for a healthier baseline.",
  },
  {
    q: "How long does it take?",
    a: "Most people complete the first assessment in around 8–10 minutes. You can pause and come back if you need to.",
  },
  {
    q: "Who can see my answers?",
    a: "Your raw answers stay private. What we use for matching is a summarized profile and compatibility signals, not a transcript.",
  },
];

export default function LandingPage() {
  const [openFaq, setOpenFaq] = useState<string | null>(faqItems[0]?.q ?? null);
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-slate-50 transition-colors duration-300">
      {/* Soft background glow */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-32 left-0 right-0 mx-auto h-64 w-64 rounded-full bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.25),_transparent_60%)] blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,_rgba(244,114,182,0.18),_transparent_60%)] blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col px-4 sm:px-6 lg:px-8">
        {/* NAVBAR */}
        <header className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 shadow-md shadow-indigo-400/30">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">
                LikeMinded
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Compatibility-first dating
              </span>
            </div>
          </div>

          <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300 md:flex">
            <a href="#about" className="hover:text-indigo-600 dark:hover:text-indigo-300">
              About
            </a>
            <a
              href="#how-it-works"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              How it works
            </a>
            <a href="#why" className="hover:text-indigo-600 dark:hover:text-indigo-300">
              Why LikeMinded
            </a>
            <a href="#faq" className="hover:text-indigo-600 dark:hover:text-indigo-300">
              FAQ
            </a>
          </nav>

          <div className="flex items-center gap-2">
            {/* Theme toggle */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle light/dark mode"
              className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-300 bg-white/70 text-slate-600 shadow-sm hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-200 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </button>
          <Link
            to="/login"
            className="hidden rounded-full border border-slate-300 bg-white/70 px-4 py-1.5 text-xs font-medium text-slate-800 shadow-sm hover:border-indigo-400 hover:text-indigo-700 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-100 dark:hover:border-indigo-400 dark:hover:text-indigo-200 sm:inline-flex"
          >
            Sign in
          </Link>
            <a
              href="/chatbot"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-1.5 text-xs font-semibold text-white shadow-md hover:brightness-110"
            >
              Start assessment
              <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </header>

        <main className="flex-1 pb-12 pt-4 md:pb-16 md:pt-10">
          {/* HERO – 2-column on desktop to use horizontal space */}
          <section id="about" className="flex flex-col pt-2 lg:pt-4">
            <div className="grid items-center gap-10 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
              {/* Left: story + CTA */}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45 }}
                className="max-w-3xl mx-auto text-center lg:mx-0 lg:text-left"
              >
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-indigo-500 dark:text-indigo-300">
                  About LikeMinded
                </p>
                <h1 className="mt-3 text-3xl font-semibold leading-tight sm:text-4xl lg:text-5xl">
                  Understanding yourself comes before{" "}
                  <span className="bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 bg-clip-text text-transparent">
                    meeting someone who fits.
                  </span>
                </h1>
                <p className="mt-4 text-sm text-slate-600 dark:text-slate-300 sm:text-[15px]">
                  LikeMinded guides you through a calm, therapist-style conversation.
                  It listens for your patterns—how you react, recover, and relate—so
                  you can connect with people who fit your emotional rhythm instead of
                  guessing from a few photos.
                </p>

                <div className="mt-6 flex flex-wrap justify-center gap-3 text-[11px] text-slate-600 dark:text-slate-300 lg:justify-start">
                  <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-3 py-1 shadow-sm ring-1 ring-slate-200 dark:bg-slate-900/80 dark:ring-slate-700">
                    <Brain className="h-3.5 w-3.5 text-indigo-500 dark:text-indigo-300" />
                    51-attribute personality profile
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-3 py-1 shadow-sm ring-1 ring-slate-200 dark:bg-slate-900/80 dark:ring-slate-700">
                    <Users2 className="h-3.5 w-3.5 text-violet-500 dark:text-violet-300" />
                    Built for thoughtful daters
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full bg-white/80 px-3 py-1 shadow-sm ring-1 ring-slate-200 dark:bg-slate-900/80 dark:ring-slate-700">
                    <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 dark:text-emerald-300" />
                    Safety & boundaries first
                  </span>
                </div>

                <div className="mt-8 flex flex-col items-center gap-3 lg:items-start">
                  <a
                    href="/chatbot"
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-6 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-md hover:brightness-110"
                  >
                    Begin your assessment
                    <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                  <a
                    href="#how-it-works"
                    className="text-[11px] sm:text-xs font-medium text-slate-600 underline-offset-4 hover:text-indigo-600 hover:underline dark:text-slate-300 dark:hover:text-indigo-300"
                  >
                    Prefer to read first? See how it works
                  </a>
                </div>
              </motion.div>

              {/* Right: chat preview + “insights” strip */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="mt-10 w-full max-w-xl mx-auto lg:mt-0 lg:mx-0"
              >
                <div className="rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-lg shadow-slate-200/60 backdrop-blur-sm dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/40">
                  <div className="flex items-center gap-3 border-b border-slate-100 pb-3 text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500">
                      <span className="text-[11px] font-semibold text-white">LM</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="font-medium text-slate-800 dark:text-slate-100">
                        LikeMinded guide
                      </span>
                      <span>Therapist-style chatbot</span>
                    </div>
                  </div>
                  <div className="mt-3 space-y-3 text-[11px] sm:text-xs">
                    {/* Bot bubble */}
                    <div className="flex items-start gap-2">
                      <div className="mt-1 h-7 w-7 shrink-0 rounded-full bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 text-[10px] font-semibold text-white grid place-items-center">
                        LM
                      </div>
                      <div className="max-w-[80%] rounded-2xl bg-slate-100 px-3 py-2 text-slate-800 dark:bg-slate-800 dark:text-slate-50">
                        When you feel overwhelmed, what usually helps you feel a bit
                        more like yourself again?
                      </div>
                    </div>
                    {/* User bubble */}
                    <div className="flex items-start justify-end gap-2">
                      <div className="max-w-[80%] rounded-2xl bg-indigo-500/90 px-3 py-2 text-slate-50 dark:bg-indigo-500">
                        I usually need a little time alone to slow down, then I can
                        talk about it.
                      </div>
                      <div className="mt-1 h-7 w-7 shrink-0 rounded-full bg-slate-200 text-[10px] font-semibold text-slate-600 grid place-items-center dark:bg-slate-700 dark:text-slate-100">
                        You
                      </div>
                    </div>
                    {/* Bot reflection */}
                    <div className="flex items-start gap-2">
                      <div className="mt-1 h-7 w-7 shrink-0 rounded-full bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 text-[10px] font-semibold text-white grid place-items-center">
                        LM
                      </div>
                      <div className="max-w-[80%] rounded-2xl bg-slate-100 px-3 py-2 text-slate-800 dark:bg-slate-800 dark:text-slate-50">
                        That tells me you regulate internally before you&apos;re ready
                        to talk. We&apos;ll keep that in mind and lean toward partners
                        who respect that rhythm.
                      </div>
                    </div>
                  </div>
                </div>

                {/* Insight strip */}
                <div className="mt-4 grid gap-3 text-[11px] sm:text-xs sm:grid-cols-3">
                  <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-900/80">
                    <div className="flex items-center gap-2">
                      <Brain className="h-3.5 w-3.5 text-indigo-500 dark:text-indigo-300" />
                      <span className="font-semibold text-slate-900 dark:text-slate-50">
                        Deep mapping
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-300">
                      Emotional, cognitive, and pacing traits scored between 0 and 1.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-900/80">
                    <div className="flex items-center gap-2">
                      <MessageSquareHeart className="h-3.5 w-3.5 text-violet-500 dark:text-violet-300" />
                      <span className="font-semibold text-slate-900 dark:text-slate-50">
                        Context-aware
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-300">
                      The guide looks at how you respond, not just what you say.
                    </p>
                  </div>
                  <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-900/80">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-500 dark:text-emerald-300" />
                      <span className="font-semibold text-slate-900 dark:text-slate-50">
                        Safety layer
                      </span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-600 dark:text-slate-300">
                      Verification and boundaries built into the matching flow.
                    </p>
                  </div>
                </div>
              </motion.div>
            </div>
          </section>

          {/* HOW IT WORKS – simple 3-step flow */}
          <section
            id="how-it-works"
            className="mt-16 border-t border-slate-200 pt-10 dark:border-slate-800"
          >
            <div className="text-center">
              <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-50">
                How LikeMinded works
              </h2>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                A short, gentle assessment powers everything: your profile,
                compatibility signals, and the people we recommend you meet.
              </p>
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-3">
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-500/10 text-xs font-semibold text-indigo-600 dark:bg-indigo-500/15 dark:text-indigo-300">
                    1
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Talk through your patterns
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  Answer therapist-style questions at your own pace. There are no
                  right answers—only honesty.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-violet-500/10 text-xs font-semibold text-violet-600 dark:bg-violet-500/15 dark:text-violet-300">
                    2
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    We map 51 attributes
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  Your emotional, cognitive, and lifestyle traits are scored between
                  0 and 1 to form your compatibility profile.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-rose-500/10 text-xs font-semibold text-rose-600 dark:bg-rose-500/15 dark:text-rose-300">
                    3
                  </span>
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Meet people who fit
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  Matches are filtered by emotional rhythm, communication style, and
                  pacing—not just proximity or photos.
                </p>
              </div>
            </div>
          </section>

          {/* WHY LIKEMINDED – human reasons */}
          <section
            id="why"
            className="mt-16 border-t border-slate-200 pt-10 dark:border-slate-800"
          >
            <div className="text-center">
              <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-50">
                Why LikeMinded exists
              </h2>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
                It&apos;s hard to build something real when you&apos;re guessing.
                We think you deserve more than “let&apos;s see what happens”.
              </p>
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <HeartHandshake className="h-4 w-4 text-indigo-500 dark:text-indigo-300" />
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Compatibility over performance
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  You&apos;re not here to perform for an algorithm. You&apos;re here
                  to find someone whose patterns make sense with yours.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <MessageSquareHeart className="h-4 w-4 text-violet-500 dark:text-violet-300" />
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Space for nuance
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  You&apos;re allowed to be complex, sensitive, or slow-to-open.
                  The assessment is designed to hold that without judgment.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-emerald-500 dark:text-emerald-300" />
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Safety is non-negotiable
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  Verification and boundaries are there so you don&apos;t have to
                  carry the whole burden of screening on your own.
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-4 text-sm shadow-sm dark:border-slate-700 dark:bg-slate-900/80">
                <div className="flex items-center gap-2">
                  <Users2 className="h-4 w-4 text-rose-500 dark:text-rose-300" />
                  <span className="font-semibold text-slate-900 dark:text-slate-50">
                    Built for people like you
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                  If you care about inner life, communication, and emotional
                  responsibility, you&apos;re in the right place.
                </p>
              </div>
            </div>
          </section>

          {/* FAQ – calm accordion */}
          <section
            id="faq"
            className="mt-16 border-t border-slate-200 py-10 dark:border-slate-800"
          >
            <div className="text-center">
              <h2 className="text-xl font-semibold text-slate-900 dark:text-slate-50">
                Frequently asked questions
              </h2>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
                A few things people often want to know before they begin.
              </p>
            </div>

            <div className="mx-auto mt-6 max-w-3xl space-y-3 text-sm">
              {faqItems.map((item) => {
                const open = openFaq === item.q;
                return (
                  <button
                    key={item.q}
                    type="button"
                    onClick={() => setOpenFaq(open ? null : item.q)}
                    className="w-full rounded-2xl border border-slate-200 bg-white/80 p-4 text-left text-slate-900 shadow-sm transition-colors hover:border-indigo-300 dark:border-slate-700 dark:bg-slate-900/80 dark:text-slate-50 dark:hover:border-indigo-400"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-medium">{item.q}</span>
                      <ChevronDown
                        className={`h-4 w-4 text-slate-400 transition-transform ${
                          open ? "rotate-180" : ""
                        }`}
                      />
                    </div>
                    {open && (
                      <p className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                        {item.a}
                      </p>
                    )}
                  </button>
                );
              })}
            </div>
          </section>
        </main>

        {/* FOOTER */}
        <footer className="border-t border-slate-200 py-4 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
          <div className="flex flex-col items-center justify-between gap-2 sm:flex-row">
            <span>© {new Date().getFullYear()} LikeMinded. All rights reserved.</span>
            <span className="text-slate-500 dark:text-slate-400">
              Built for people who want clarity before connection.
            </span>
          </div>
        </footer>
      </div>
    </div>
  );
}
