import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Sparkles,
  ShieldCheck,
  Mail,
  Lock,
  User2,
  LogIn,
  UserPlus,
  Moon,
  Sun,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { supabase } from "../lib/supabaseClient";
import { useAuth } from "../auth/AuthProvider";
import { api } from "../lib/api";
import { useTheme } from "../theme/ThemeProvider";

export default function LoginPage() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();

  const from = (location.state as any)?.from?.pathname || "/conversations";
  const initialPhase: "auth" | "onboarding" =
    (location.state as any)?.onboarding === true ? "onboarding" : "auth";

  const [phase, setPhase] = useState<"auth" | "onboarding">(initialPhase);

  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Sign in form
  const [emailIn, setEmailIn] = useState("");
  const [passwordIn, setPasswordIn] = useState("");

  // Sign up form
  const [fullName, setFullName] = useState("");
  const [emailUp, setEmailUp] = useState("");
  const [passwordUp, setPasswordUp] = useState("");
  const [confirmUp, setConfirmUp] = useState("");

  // Onboarding form
  const [age, setAge] = useState("");
  const [locationInput, setLocationInput] = useState("");
  const [prefMin, setPrefMin] = useState("");
  const [prefMax, setPrefMax] = useState("");
  const [prefGender, setPrefGender] = useState<
    "women" | "men" | "everyone" | null
  >(null);
  const [selfGender, setSelfGender] = useState<
    "woman" | "man" | "nonbinary" | null
  >(null);

  function clearMsgs() {
    setNotice(null);
    setError(null);
  }

  async function signInWithGoogle() {
    clearMsgs();
    setBusy(true);
    try {
      sessionStorage.setItem("post_login_redirect", from);
      const redirectTo = `${window.location.origin}/auth/callback`;
      const { error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo },
      });
      if (error) throw error;
    } catch (e: any) {
      setError(e?.message || "Google sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onSignIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    clearMsgs();
    setBusy(true);
    try {
      sessionStorage.setItem("post_login_redirect", from);
      const { error } = await supabase.auth.signInWithPassword({
        email: emailIn,
        password: passwordIn,
      });
      if (error) throw error;
      navigate(from, { replace: true });
    } catch (e: any) {
      setError(e?.message || "Authentication failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onForgotPassword() {
    clearMsgs();
    if (!emailIn) {
      setError("Enter your email above, then click Forgot password.");
      return;
    }
    setBusy(true);
    try {
      const redirectTo = `${window.location.origin}/auth/callback`;
      const { error } = await supabase.auth.resetPasswordForEmail(emailIn, {
        redirectTo,
      });
      if (error) throw error;
      setNotice("Password reset link sent. Check your email.");
    } catch (e: any) {
      setError(e?.message || "Could not send reset link.");
    } finally {
      setBusy(false);
    }
  }

  async function onSignUp(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    clearMsgs();

    if (!fullName.trim()) {
      setError("Please enter your full name.");
      return;
    }
    if (passwordUp.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (passwordUp !== confirmUp) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);
    try {
      sessionStorage.setItem("post_login_redirect", from);
      const redirectTo = `${window.location.origin}/auth/callback`;
      const { data, error } = await supabase.auth.signUp({
        email: emailUp,
        password: passwordUp,
        options: {
          emailRedirectTo: redirectTo,
          data: { full_name: fullName },
        },
      });
      if (error) throw error;

      if (!data.user || !data.session) {
        setNotice("Account created! Check your email to confirm your address.");
        return;
      }

      // After sign up with active session, go into onboarding
      setPhase("onboarding");
    } catch (e: any) {
      setError(e?.message || "Sign up failed.");
    } finally {
      setBusy(false);
    }
  }

  async function onCompleteOnboarding(
    e: React.FormEvent<HTMLFormElement>
  ): Promise<void> {
    e.preventDefault();
    clearMsgs();

    if (!age || Number.isNaN(Number(age))) {
      setError("Please enter your age.");
      return;
    }
    if (!selfGender) {
      setError("Please select your gender.");
      return;
    }

    setBusy(true);
    try {
      const payload = {
        age: Number(age),
        location: locationInput.trim() || null,
        gender: selfGender, // make sure your backend & api.completeOnboarding accept this
        preferred_min_age: prefMin ? Number(prefMin) : null,
        preferred_max_age: prefMax ? Number(prefMax) : null,
        preferred_gender: prefGender,
      };

      await api.completeOnboarding(payload);

      // After onboarding, always go to chatbot assessment
      navigate("/chatbot", { replace: true });
    } catch (e: any) {
      setError(e?.message || "Could not save your preferences.");
    } finally {
      setBusy(false);
    }
  }

  // Signed-in compact panel (logic unchanged)
  if (user && phase === "auth") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-slate-50 transition-colors duration-300">
        {/* background glow */}
        <div className="pointer-events-none fixed inset-0 -z-10">
          <div className="absolute -top-32 left-0 right-0 mx-auto h-64 w-64 rounded-full bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.25),_transparent_60%)] blur-3xl" />
          <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,_rgba(244,114,182,0.18),_transparent_60%)] blur-3xl" />
        </div>

        <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-4 sm:px-6 lg:px-8">
          {/* NAVBAR – matched to landing */}
          <header className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 shadow-md shadow-indigo-400/30">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
              <div className="flex flex-col leading-tight">
                <span className="text-sm font-semibold tracking-tight">
                  LikeMinded
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Compatibility-first dating
                </span>
              </div>
            </div>

            <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300 md:flex">
              <a
                href="/"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Home
              </a>
              <Link
                to="/chatbot"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Assessment
              </Link>
              <Link
                to="/conversations"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Conversations
              </Link>
            </nav>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleTheme}
                aria-label="Toggle light/dark mode"
                className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-300 bg-white/70 text-slate-600 shadow-sm hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-200 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
              >
                {theme === "dark" ? (
                  <Sun className="h-4 w-4" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
              </button>
            </div>
          </header>

          <main className="flex flex-1 items-center justify-center py-10">
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md"
            >
              <div className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-lg shadow-slate-200/60 backdrop-blur-sm dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/40">
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-300">
                  <ShieldCheck className="h-5 w-5" />
                  <h1 className="text-sm font-semibold">You’re signed in</h1>
                </div>

                <div className="mt-4 space-y-1 text-sm text-slate-600 dark:text-slate-300">
                  <div>
                    <span className="font-medium text-slate-800 dark:text-slate-100">
                      Name:
                    </span>{" "}
                    {user.name || "—"}
                  </div>
                  <div>
                    <span className="font-medium text-slate-800 dark:text-slate-100">
                      Email:
                    </span>{" "}
                    {user.email || "—"}
                  </div>
                </div>

                <div className="mt-6 grid gap-3 text-sm">
                  <button
                    onClick={() => navigate("/conversations")}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-2 font-medium text-white shadow-md hover:brightness-110"
                  >
                    <LogIn className="h-4 w-4" /> Go to conversations
                  </button>
                  <button
                    onClick={signOut}
                    className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white/70 px-4 py-2 font-medium text-slate-800 hover:border-indigo-400 hover:text-indigo-700 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-100 dark:hover:border-rose-400 dark:hover:text-rose-200"
                  >
                    Sign out
                  </button>
                </div>
              </div>
            </motion.div>
          </main>
        </div>
      </div>
    );
  }

  // Auth + onboarding
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-slate-50 transition-colors duration-300">
      {/* background glow */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-32 left-0 right-0 mx-auto h-64 w-64 rounded-full bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.25),_transparent_60%)] blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,_rgba(244,114,182,0.18),_transparent_60%)] blur-3xl" />
      </div>

      <div className="mx-auto flex min-h-screen max-w-6xl flex-col px-4 sm:px-6 lg:px-8">
        {/* NAVBAR – aligned with landing */}
        <header className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 shadow-md shadow-indigo-400/30">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">
                LikeMinded
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Compatibility-first dating
              </span>
            </div>
          </div>

          <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300 md:flex">
            <a
              href="/"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Home
            </a>
            <Link
              to="/chatbot"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Assessment
            </Link>
            <Link
              to="/conversations"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Conversations
            </Link>
          </nav>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle light/dark mode"
              className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-300 bg-white/70 text-slate-600 shadow-sm hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-200 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </button>
          </div>
        </header>

        <main className="flex flex-1 items-center justify-center py-10">
          <div className="w-full max-w-md">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              className="rounded-3xl border border-slate-200 bg-white/80 p-6 shadow-lg shadow-slate-200/60 backdrop-blur-sm dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/40"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-indigo-500 dark:text-indigo-300">
                    Sign in to continue
                  </div>
                  <h1 className="mt-2 text-xl font-semibold text-slate-900 dark:text-slate-50">
                    Welcome back to LikeMinded
                  </h1>
                  <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
                    Use your email or Google. We’ll only use this to manage your
                    account and matches.
                  </p>
                </div>
                <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500">
                  <ShieldCheck className="h-4 w-4 text-white" />
                </div>
              </div>

              {/* Tabs */}
              <div className="mt-5 grid grid-cols-2 rounded-2xl border border-slate-200 bg-slate-50/80 p-1 text-xs font-medium text-slate-600 dark:border-slate-700 dark:bg-slate-900/60 dark:text-slate-300">
                <button
                  type="button"
                  onClick={() => {
                    setMode("signin");
                    clearMsgs();
                  }}
                  className={`rounded-xl py-1.5 transition ${
                    mode === "signin"
                      ? "bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-slate-50"
                      : "hover:text-indigo-600 dark:hover:text-indigo-300"
                  }`}
                >
                  Sign in
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode("signup");
                    clearMsgs();
                  }}
                  className={`rounded-xl py-1.5 transition ${
                    mode === "signup"
                      ? "bg-white text-slate-900 shadow-sm dark:bg-slate-800 dark:text-slate-50"
                      : "hover:text-indigo-600 dark:hover:text-indigo-300"
                  }`}
                >
                  Create account
                </button>
              </div>

              {/* Panels */}
              <div className="relative mt-4">
                <div className="h-px bg-slate-100 dark:bg-slate-700" />
                <AnimatePresence mode="popLayout" initial={false}>
                  {mode === "signin" ? (
                    <motion.div
                      key="signin-panel"
                      initial={{ x: 24, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      exit={{ x: -24, opacity: 0 }}
                      transition={{ duration: 0.22 }}
                    >
                      <form onSubmit={onSignIn} className="space-y-3 pt-4 text-sm">
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Email address
                        </label>
                        <div className="relative">
                          <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            type="email"
                            value={emailIn}
                            onChange={(e) => setEmailIn(e.target.value)}
                            required
                            placeholder="you@example.com"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                          />
                        </div>

                        <label className="mt-3 block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Password
                        </label>
                        <div className="relative">
                          <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            type="password"
                            value={passwordIn}
                            onChange={(e) => setPasswordIn(e.target.value)}
                            required
                            placeholder="••••••••"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                            minLength={6}
                          />
                        </div>

                        <div className="mt-2 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                          <label className="inline-flex items-center gap-2">
                            <input
                              type="checkbox"
                              className="h-3.5 w-3.5 rounded border-slate-300 text-indigo-500 focus:ring-indigo-400 dark:border-slate-600"
                              defaultChecked
                            />
                            Remember for 30 days
                          </label>
                          <button
                            type="button"
                            onClick={onForgotPassword}
                            className="font-medium text-indigo-600 hover:underline dark:text-indigo-300"
                          >
                            Forgot password
                          </button>
                        </div>

                        <button
                          type="submit"
                          disabled={busy}
                          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-2.5 text-sm font-semibold text-white shadow-md hover:brightness-110 disabled:opacity-60"
                        >
                          <LogIn className="h-4 w-4" />
                          Sign in
                        </button>
                      </form>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="signup-panel"
                      initial={{ x: -24, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      exit={{ x: 24, opacity: 0 }}
                      transition={{ duration: 0.22 }}
                    >
                      <form onSubmit={onSignUp} className="space-y-3 pt-4 text-sm">
                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Full name
                        </label>
                        <div className="relative">
                          <User2 className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            required
                            placeholder="Alex Johnson"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                          />
                        </div>

                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Email address
                        </label>
                        <div className="relative">
                          <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            type="email"
                            value={emailUp}
                            onChange={(e) => setEmailUp(e.target.value)}
                            required
                            placeholder="you@example.com"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                          />
                        </div>

                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Password
                        </label>
                        <div className="relative">
                          <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            type="password"
                            value={passwordUp}
                            onChange={(e) => setPasswordUp(e.target.value)}
                            required
                            placeholder="••••••••"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                            minLength={6}
                          />
                        </div>

                        <label className="block text-xs font-medium text-slate-700 dark:text-slate-200">
                          Confirm password
                        </label>
                        <div className="relative">
                          <Lock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                          <input
                            type="password"
                            value={confirmUp}
                            onChange={(e) => setConfirmUp(e.target.value)}
                            required
                            placeholder="••••••••"
                            className="w-full rounded-2xl border border-slate-200 bg-white px-9 py-2 text-sm text-slate-900 shadow-sm outline-none ring-0 placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                            minLength={6}
                          />
                        </div>

                        <button
                          type="submit"
                          disabled={busy}
                          className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white shadow-md hover:bg-black disabled:opacity-60 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
                        >
                          <UserPlus className="h-4 w-4" />
                          Create account
                        </button>
                      </form>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Divider */}
              <div className="my-5 flex items-center gap-3">
                <div className="h-px flex-1 bg-slate-100 dark:bg-slate-700" />
                <div className="text-[11px] uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">
                  or
                </div>
                <div className="h-px flex-1 bg-slate-100 dark:bg-slate-700" />
              </div>

              {/* Google button */}
              <button
                onClick={signInWithGoogle}
                disabled={busy}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-slate-200 bg-white/80 px-4 py-2.5 text-sm font-medium text-slate-800 shadow-sm hover:border-indigo-400 hover:text-indigo-700 disabled:opacity-60 dark:border-slate-700 dark:bg-slate-900/80 dark:text-slate-100 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
                title="Sign in with Google"
              >
                <img
                  src="https://www.svgrepo.com/show/475656/google-color.svg"
                  alt=""
                  className="h-4 w-4 rounded-[2px] bg-white"
                />
                Continue with Google
              </button>

              {/* Notices */}
              {notice && (
                <div className="mt-4 text-xs text-emerald-600 dark:text-emerald-300">
                  {notice}
                </div>
              )}
              {error && (
                <div className="mt-3 text-xs text-rose-600 dark:text-rose-300">
                  {error}
                </div>
              )}

              {/* Footer hint */}
              <div className="mt-6 text-center text-xs text-slate-600 dark:text-slate-300">
                {mode === "signin" ? (
                  <>
                    Don’t have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setMode("signup")}
                      className="font-medium text-indigo-600 hover:underline dark:text-indigo-300"
                    >
                      Sign up
                    </button>
                  </>
                ) : (
                  <>
                    Already have an account?{" "}
                    <button
                      type="button"
                      onClick={() => setMode("signin")}
                      className="font-medium text-indigo-600 hover:underline dark:text-indigo-300"
                    >
                      Sign in
                    </button>
                  </>
                )}
              </div>
            </motion.div>
          </div>
        </main>
      </div>

      {/* Onboarding sheet */}
      {phase === "onboarding" && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md rounded-3xl border border-slate-200 bg-white/95 p-6 shadow-2xl dark:border-slate-700 dark:bg-slate-900/95"
          >
            <h2 className="text-base font-semibold text-slate-900 dark:text-slate-50">
              Set up your profile
            </h2>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">
              This helps us match you with people who actually fit your pace and preferences.
            </p>

            <form
              onSubmit={onCompleteOnboarding}
              className="mt-4 space-y-3 text-sm"
            >
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-200">
                  Your age
                </label>
                <input
                  type="number"
                  min={18}
                  max={99}
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                  required
                />
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-200">
                  Location
                </label>
                <input
                  type="text"
                  value={locationInput}
                  onChange={(e) => setLocationInput(e.target.value)}
                  placeholder="City, Country"
                  className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                />
              </div>

              {/* Your gender */}
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-200">
                  Your gender
                </label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { value: "woman" as const, label: "Woman" },
                    { value: "man" as const, label: "Man" },
                    { value: "nonbinary" as const, label: "Non-binary" },
                  ].map((opt) => {
                    const active = selfGender === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setSelfGender(opt.value)}
                        className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                          active
                            ? "border-slate-900 bg-slate-900 text-slate-50 shadow-sm dark:border-slate-100 dark:bg-slate-100 dark:text-slate-900"
                            : "border-slate-300 bg-white text-slate-700 hover:border-indigo-400 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-indigo-400"
                        }`}
                      >
                        {opt.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-200">
                  Preferred age range
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min={18}
                    max={99}
                    value={prefMin}
                    onChange={(e) => setPrefMin(e.target.value)}
                    placeholder="Min"
                    className="w-1/2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                  />
                  <input
                    type="number"
                    min={18}
                    max={99}
                    value={prefMax}
                    onChange={(e) => setPrefMax(e.target.value)}
                    placeholder="Max"
                    className="w-1/2 rounded-2xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs font-medium text-slate-700 dark:text-slate-200">
                  Gender preference
                </label>
                <div className="flex flex-wrap gap-2">
                  {(["women", "men", "everyone"] as const).map((g) => {
                    const active = prefGender === g;
                    return (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setPrefGender(g)}
                        className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                          active
                            ? "border-rose-500 bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 text-white shadow-sm"
                            : "border-slate-300 bg-white text-slate-700 hover:border-indigo-400 dark:border-slate-600 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-indigo-400"
                        }`}
                      >
                        {g[0].toUpperCase() + g.slice(1)}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="mt-4 flex justify-end gap-2 text-xs">
                <button
                  type="submit"
                  disabled={busy}
                  className="rounded-full bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-2 font-semibold text-white shadow-md hover:brightness-110 disabled:opacity-60"
                >
                  Save and continue
                </button>
              </div>

              {error && (
                <div className="mt-3 text-xs text-rose-600 dark:text-rose-300">
                  {error}
                </div>
              )}
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
}
