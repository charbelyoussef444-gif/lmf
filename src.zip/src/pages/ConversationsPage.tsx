import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Sparkles,
  SendHorizontal,
  Search,
  Loader2,
  Clock,
  MessageSquareHeart,
  ShieldCheck,
  ArrowRight,
  Star,
  Filter,
  Plus,
  MoreVertical,
  Moon,
  Sun,
} from "lucide-react";
import { Link } from "react-router-dom";
import {
  api,
  type Conversation,
  type Msg,
  type MatchResponse,
  type MatchStatus,
} from "../lib/api";
import { supabase } from "../lib/supabaseClient";
import AuthStatus from "../components/AuthStatus";
import { useTheme } from "../theme/ThemeProvider";

/** ---------------- WebSocket minimal client (matches backend events) ---------------- */

type WsMessageData = {
  id: string;
  conversation_id: string;
  sender_user_id?: string | null;
  receiver_user_id?: string | null;
  content_text?: string | null;
  created_at: string; // ISO
};

type WsEvent =
  | { type: "message-new"; data: WsMessageData }
  | { type: "typing"; userId: string; isTyping: boolean }
  | { type: "read"; userId: string }
  | { type: "presence"; userId: string; state: "joined" | "left" }
  | { type: "pong" };

function useConversationWS(opts: {
  apiBase: string;
  cid: string | null;
  token: string | null;
  onEvent?: (evt: WsEvent) => void;
}) {
  const { apiBase, cid, token, onEvent } = opts;
  const [status, setStatus] = useState<
    "disconnected" | "connecting" | "connected"
  >("disconnected");
  const wsRef = useRef<WebSocket | null>(null);
  const pingRef = useRef<number | null>(null);

  // keep callback stable for ws.onmessage
  const onEventRef = useRef<typeof onEvent | null>(null);
  useEffect(() => {
    onEventRef.current = onEvent || null;
  }, [onEvent]);

  useEffect(() => {
    if (!cid || !token) return;

    let retry = 0;

    // derive ws base from api base (http->ws, https->wss)
    const rawBase = (
      import.meta.env.VITE_API_BASE_URL || apiBase || ""
    ).replace(/\/+$/, "");
    const wsBase = rawBase.replace(
      /^http(s?):\/\//,
      (_m: string, s: string) => `ws${s ? "s" : ""}://`
    );
    const url = `${wsBase}/ws/conversations/${cid}?token=${encodeURIComponent(
      token
    )}`;

    function connect() {
      setStatus("connecting");
      const ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        setStatus("connected");
        retry = 0;
        // heartbeat
        pingRef.current = window.setInterval(() => {
          try {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: "ping" }));
            }
          } catch {
            /* noop */
          }
        }, 25000);
      };

      ws.onmessage = (ev) => {
        try {
          const evt = JSON.parse(ev.data) as WsEvent;
          onEventRef.current?.(evt);
        } catch {
          // ignore malformed frames
        }
      };

      ws.onclose = () => {
        setStatus("disconnected");
        if (pingRef.current) {
          clearInterval(pingRef.current);
          pingRef.current = null;
        }
        // basic exponential backoff
        const delay = Math.min(1000 * 2 ** retry, 15000);
        retry += 1;
        window.setTimeout(connect, delay);
      };

      ws.onerror = () => {
        try {
          ws.close();
        } catch {}
      };
    }

    connect();

    return () => {
      if (pingRef.current) {
        clearInterval(pingRef.current);
        pingRef.current = null;
      }
      const s = wsRef.current;
      if (s && s.readyState === WebSocket.OPEN) s.close();
      wsRef.current = null;
    };
  }, [apiBase, cid, token]); // IMPORTANT: no onEvent here

  const safeSend = (payload: unknown) => {
    const s = wsRef.current;
    if (!s || s.readyState !== WebSocket.OPEN) return false;
    try {
      s.send(JSON.stringify(payload));
      return true;
    } catch {
      return false;
    }
  };

  const sendText = (text: string) => safeSend({ type: "send", text });
  const setTyping = (isTyping: boolean) => safeSend({ type: "typing", isTyping });
  const markRead = () => safeSend({ type: "read" });

  return { status, sendText, setTyping, markRead };
}

/** ---------------- Match error + CTA block ---------------- */

function MatchErrorActions({
  matchError,
  verified,
  assessmentIncomplete,
  align = "left",
}: {
  matchError: string | null;
  verified: boolean | null;
  assessmentIncomplete: boolean | null;
  align?: "left" | "center";
}) {
  const issues: string[] = [];

  if (verified === false) {
    issues.push("Your account is not verified.");
  }
  if (assessmentIncomplete === true) {
    issues.push("Your compatibility assessment is not complete.");
  }

  // If backend gives a generic reason that isn't covered above, keep it.
  if (matchError && issues.length === 0) {
    issues.push(matchError);
  }

  const showVerify = verified === false;
  const showAssessment = assessmentIncomplete === true;

  if (!matchError && issues.length === 0 && !showVerify && !showAssessment) {
    return null;
  }

  const alignClasses =
    align === "center" ? "items-center text-center" : "items-start text-left";
  const buttonsJustify = align === "center" ? "justify-center" : "";

  return (
    <div
      className={`mt-1 flex flex-col gap-1 rounded-xl bg-rose-50/70 p-2.5 text-[11px] text-rose-700 dark:bg-rose-950/40 dark:text-rose-200 ${alignClasses}`}
    >
      {issues.length > 0 && (
        <ul className="list-disc pl-4 marker:text-rose-400 dark:marker:text-rose-300">
          {issues.map((txt, i) => (
            <li key={i}>{txt}</li>
          ))}
        </ul>
      )}

      {matchError && issues.length === 0 && <span>{matchError}</span>}

      {(showVerify || showAssessment) && (
        <div className={`mt-1 flex flex-wrap gap-2 ${buttonsJustify}`}>
          {showVerify && (
            <Link
              to="/profile"
              className="inline-flex items-center gap-1 rounded-full border border-rose-300 bg-white/80 px-2.5 py-0.5 text-[10px] font-medium text-rose-700 hover:bg-rose-50 dark:border-rose-500/60 dark:bg-rose-950/60 dark:text-rose-100"
            >
              <ShieldCheck className="h-3 w-3" />
              <span>Verify now</span>
            </Link>
          )}
          {showAssessment && (
            <Link
              to="/chatbot"
              className="inline-flex items-center gap-1 rounded-full border border-indigo-300 bg-white/80 px-2.5 py-0.5 text-[10px] font-medium text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/60 dark:bg-indigo-950/60 dark:text-indigo-100"
            >
              <Sparkles className="h-3 w-3" />
              <span>Complete assessment</span>
            </Link>
          )}
        </div>
      )}
    </div>
  );
}

/** ---------------- Page ---------------- */
export default function ConversationsPage() {
  const [convos, setConvos] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [thread, setThread] = useState<Msg[]>([]);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState("");

  // kebab menu state (which convo row's menu is open)
  const [menuFor, setMenuFor] = useState<string | null>(null);

  // Supabase user id for role mapping in realtime & token for WS auth
  const [meId, setMeId] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  useEffect(() => {
    (async () => {
      const [{ data: u }, { data: s }] = await Promise.all([
        supabase.auth.getUser(),
        supabase.auth.getSession(),
      ]);
      setMeId(u.user?.id ?? null);
      setToken(s.session?.access_token ?? null);
    })().catch(() => {
      setMeId(null);
      setToken(null);
    });
  }, []);

  // match eligibility info from backend
  const [matchAllowed, setMatchAllowed] = useState<boolean>(false);
  const [nextEligibleAt, setNextEligibleAt] = useState<number | null>(null);

  // error/status UX for match button
  const [matchError, setMatchError] = useState<string | null>(null);

  // profile / assessment status for CTAs
  const [verified, setVerified] = useState<boolean | null>(null);
  const [assessmentIncomplete, setAssessmentIncomplete] = useState<boolean | null>(
    null
  );

  // load profile + assessment state
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [profile, history] = await Promise.all([
          api.me(),
          api.chatbotHistory().catch(() => null),
        ]);
        if (!alive) return;

        setVerified(profile.verified);

        if (history) {
          const { phase, progress } = history;
          const selfIncomplete = progress.self_filled < progress.self_total;
          const prefIncomplete =
            typeof progress.pref_total === "number" &&
            typeof progress.pref_filled === "number"
              ? progress.pref_filled < progress.pref_total
              : phase !== "done";

          setAssessmentIncomplete(
            selfIncomplete || prefIncomplete || phase !== "done"
          );
        } else {
          // if we can't fetch history at all, assume not complete
          setAssessmentIncomplete(true);
        }
      } catch {
        if (!alive) return;
        setVerified(null);
        setAssessmentIncomplete(null);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  // dynamic cooldown countdown math
  const now = useNow(1000);
  const remainingMs = useMemo(() => {
    if (nextEligibleAt == null) {
      return 0;
    }
    return Math.max(0, nextEligibleAt - now);
  }, [nextEligibleAt, now]);

  const canMatch = matchAllowed && remainingMs === 0;
  const countdown = msToClock(remainingMs);

  // Load conversations once
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const data = await api.conversations();
        if (alive) setConvos(data);
      } catch (e) {
        console.error(e);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  // Load match status once on mount
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const st: MatchStatus = await api.matchStatus();
        if (!alive) return;

        // eligibility now
        setMatchAllowed(st.eligible);

        // cooldown time (if applicable)
        if (st.next_eligible_ts_utc) {
          const ms = Date.parse(st.next_eligible_ts_utc);
          setNextEligibleAt(Number.isNaN(ms) ? null : ms);
        } else {
          setNextEligibleAt(null);
        }

        // reason display
        if (!st.eligible && st.reason) {
          setMatchError(st.reason);
        } else {
          setMatchError(null);
        }
      } catch (e) {
        console.error(e);
        if (!alive) return;
        setMatchAllowed(false);
        setNextEligibleAt(null);
        setMatchError("Unable to check eligibility.");
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  // local state for "Get New Match"
  const [matchLoading, setMatchLoading] = useState(false);

  // Memoized WS handler
  const onWsEvent = useCallback(
    (evt: WsEvent) => {
      switch (evt.type) {
        case "message-new": {
          const d = evt.data;

          const role: "me" | "them" =
            meId && d.sender_user_id === meId ? "me" : "them";

          setThread((t) => {
            // 1. If this exact DB message already exists, no-op
            const alreadyThere = t.some((msg) => msg.id === d.id);
            if (alreadyThere) return t;

            // 2. If it's *my* message, try to replace the most recent optimistic temp message
            if (role === "me") {
              // find last temp-"me" message
              const idx = [...t]
                .reverse()
                .findIndex((m) => m.role === "me" && m.id.startsWith("temp-"));

              if (idx !== -1) {
                // reverse() messed with index, fix it back to real index
                const realIndex = t.length - 1 - idx;
                const clone = t.slice();
                clone[realIndex] = {
                  id: d.id,
                  role,
                  text: d.content_text ?? undefined,
                  ts: Math.floor(new Date(d.created_at).getTime() / 1000),
                };
                return clone;
              }
            }

            // 3. Otherwise just append as a new message (e.g. message from "them")
            return [
              ...t,
              {
                id: d.id,
                role,
                text: d.content_text ?? undefined,
                ts: Math.floor(new Date(d.created_at).getTime() / 1000),
              },
            ];
          });

          break;
        }

        case "typing":
          break;

        case "read":
        case "presence":
        case "pong":
        default:
          break;
      }
    },
    [meId]
  );

  // Realtime WS for active conversation
  const {
    status: wsStatus,
    sendText,
    setTyping,
    markRead: markReadWS,
  } = useConversationWS({
    apiBase: import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000",
    cid: activeId,
    token,
    onEvent: onWsEvent,
  });

  async function openConversation(id: string) {
    setActiveId(id);
    setMenuFor(null);
    // fetch history
    const msgs = await api.thread(id);
    setThread(msgs);
    // mark read via WS and HTTP fallback
    try {
      markReadWS();
    } catch {}
    api.markRead(id).catch(() => {});
  }

  async function send() {
    if (!message.trim() || !activeId || sending) return;
    setSending(true);

    const text = message.trim();
    const tempId = "temp-" + crypto.randomUUID();
    setThread((t) => [
      ...t,
      {
        id: tempId,
        role: "me",
        text,
        ts: Math.floor(Date.now() / 1000),
      },
    ]);

    setMessage("");

    try {
      // Prefer WS; fallback to REST if WS is not connected
      if (wsStatus === "connected") {
        sendText(text);
      } else {
        await api.sendMessage(activeId, text);
      }
    } finally {
      setSending(false);
    }
  }

  // end chat action
  async function endChat(cid: string) {
    try {
      await api.endConversation(cid);

      // Remove convo from list
      setConvos((prev) => prev.filter((c) => c.id !== cid));

      // If we just ended the active chat, clear right panel
      setThread((t) => (activeId === cid ? [] : t));
      setActiveId((id) => (id === cid ? null : id));
    } catch (err) {
      console.error("Failed to end chat", err);
      alert("Couldn't end this chat. Please try again.");
    } finally {
      setMenuFor(null);
    }
  }

  // request a new match using backend
  async function getNewMatch() {
    if (matchLoading) return;
    setMatchLoading(true);

    try {
      const res: MatchResponse = await api.match();

      if (res.status === "matched") {
        // refresh convos
        const updated = await api.conversations();
        setConvos(updated);

        // open the new convo
        if (res.conversation_id) {
          setActiveId(res.conversation_id);
          const msgs = await api.thread(res.conversation_id);
          setThread(msgs);
        }

        // refresh status (cooldown etc.)
        const st = await api.matchStatus();
        setMatchAllowed(st.eligible);
        if (st.next_eligible_ts_utc) {
          const ms = Date.parse(st.next_eligible_ts_utc);
          setNextEligibleAt(Number.isNaN(ms) ? null : ms);
        } else {
          setNextEligibleAt(null);
        }
        setMatchError(st.eligible ? null : st.reason || null);
      } else if (res.status === "ineligible") {
        setMatchError(res.reason || "Not eligible yet.");

        const st = await api.matchStatus();
        setMatchAllowed(st.eligible);
        if (st.next_eligible_ts_utc) {
          const ms = Date.parse(st.next_eligible_ts_utc);
          setNextEligibleAt(Number.isNaN(ms) ? null : ms);
        } else {
          setNextEligibleAt(null);
        }
      } else if (res.status === "no_match") {
        setMatchError("No compatible match found right now.");
      } else {
        setMatchError("Unexpected response.");
      }
    } catch (err) {
      console.error(err);
      setMatchError("Something went wrong.");
    } finally {
      setMatchLoading(false);
    }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return convos;
    return convos.filter((c) =>
      [c.partnerName, c.partnerCity, c.lastMessage].some((v) =>
        v?.toLowerCase().includes(q)
      )
    );
  }, [search, convos]);

  const active = convos.find((c) => c.id === activeId) || null;
  const bottomRef = useRef<HTMLDivElement | null>(null);
  useEffect(
    () => bottomRef.current?.scrollIntoView({ behavior: "smooth" }),
    [thread, activeId]
  );

  const hasAnyConvos = convos.length > 0;
  const { theme, toggleTheme } = useTheme();

  const hasBlockingReasons =
    !canMatch ||
    verified === false ||
    assessmentIncomplete === true ||
    !!matchError;

  const showTopMatchButton = !hasBlockingReasons;

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 dark:text-slate-50 transition-colors duration-300">
      {/* Soft background glow */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-32 left-0 right-0 mx-auto h-64 w-64 rounded-full bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.25),_transparent_60%)] blur-3xl" />
        <div className="absolute bottom-0 right-0 h-72 w-72 rounded-full bg-[radial-gradient(circle_at_center,_rgba(244,114,182,0.18),_transparent_60%)] blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <header className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 shadow-md shadow-indigo-400/30">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold tracking-tight">
                LikeMinded
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                Compatibility-first dating
              </span>
            </div>
          </div>

          <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-300 md:flex">
            <Link
              to="/"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Home
            </Link>
            <Link
              to="/chatbot"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Assessment
            </Link>
            <Link
              to="/profile"
              className="hover:text-indigo-600 dark:hover:text-indigo-300"
            >
              Profile
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <div className="hidden text-[11px] items-center gap-1 rounded-full border border-emerald-400/40 bg-emerald-50/70 px-3 py-1 font-medium text-emerald-700 dark:border-emerald-500/40 dark:bg-emerald-900/40 dark:text-emerald-200 sm:inline-flex">
              <ShieldCheck className="h-3.5 w-3.5" />
              Verified community
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle light/dark mode"
              className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-slate-300 bg-white/70 text-slate-600 shadow-sm hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-600 dark:bg-slate-900/70 dark:text-slate-200 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
            >
              {theme === "dark" ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
            </button>
          </div>
        </header>

        {/* Main layout */}
        <main className="flex-1 py-6">
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1.95fr)]">
            {/* Left: Conversations list */}
            <aside className="flex min-h-[70vh] flex-col rounded-3xl border border-slate-200 bg-white/80 p-4 shadow-sm shadow-slate-200/60 backdrop-blur dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/30">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <MessageSquareHeart className="h-5 w-5 text-indigo-500 dark:text-indigo-300" />
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                    Conversations
                  </h2>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {convos.length} active
                </div>
              </div>

              {/* Search + filters */}
              <div className="mt-3 flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by name, city, message…"
                    className="w-full rounded-2xl border border-slate-200 bg-white/80 px-9 py-2 text-xs text-slate-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                  />
                </div>
                <button
                  className="inline-flex items-center gap-1 rounded-2xl border border-slate-200 bg-white/70 px-3 py-2 text-[11px] text-slate-600 hover:border-indigo-400 hover:text-indigo-600 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-200 dark:hover:border-indigo-400 dark:hover:text-indigo-200"
                  title="Filters (coming soon)"
                >
                  <Filter className="h-3.5 w-3.5" />
                  Filters
                </button>
              </div>

              {/* Match card */}
              <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50/80 p-4 text-xs text-slate-700 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-200">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex flex-1 flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-indigo-500 dark:text-indigo-300" />
                      {canMatch ? (
                        <span>You’re eligible for a new match now.</span>
                      ) : nextEligibleAt ? (
                        <span>Next curated match in {countdown}.</span>
                      ) : (
                        <span>Matching is currently unavailable.</span>
                      )}
                    </div>
                    <MatchErrorActions
                      matchError={matchError}
                      verified={verified}
                      assessmentIncomplete={assessmentIncomplete}
                      align="left"
                    />
                  </div>

                  {showTopMatchButton && (
                    <button
                      onClick={getNewMatch}
                      disabled={matchLoading}
                      className={
                        "inline-flex items-center gap-2 rounded-full px-3 py-1.5 text-[11px] font-medium " +
                        (matchLoading
                          ? "bg-slate-200 text-slate-500 cursor-wait dark:bg-slate-800 dark:text-slate-400"
                          : "bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 text-white shadow-sm hover:brightness-110")
                      }
                      title={matchLoading ? "Matching..." : "Find a new match"}
                    >
                      {matchLoading ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Plus className="h-3.5 w-3.5" />
                      )}
                      <span>New match</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Conversation list */}
              <div
                className="mt-4 space-y-1 overflow-y-auto pr-1"
                style={{ maxHeight: "58vh" }}
              >
                {filtered.map((c) => {
                  const isActive = activeId === c.id;
                  const isMenuOpen = menuFor === c.id;

                  return (
                    <div
                      key={c.id}
                      className={`flex items-start gap-2 rounded-2xl px-2 py-2 transition ${
                        isActive
                          ? "bg-indigo-50/80 ring-1 ring-indigo-200 dark:bg-indigo-950/40 dark:ring-indigo-800/60"
                          : "hover:bg-slate-50/80 dark:hover:bg-slate-800/60"
                      }`}
                    >
                      {/* Left/main clickable area opens the conversation */}
                      <button
                        onClick={() => openConversation(c.id)}
                        className="flex flex-1 items-start gap-3 text-left"
                      >
                        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gradient-to-tr from-indigo-500 via-violet-500 to-rose-500 text-xs font-semibold text-white">
                          {c.partnerName?.substring(0, 1) ?? "?"}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <div className="truncate text-sm font-medium text-slate-900 dark:text-slate-50">
                              {c.partnerName}
                              {c.partnerAge ? (
                                <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
                                  {" "}
                                  · {c.partnerAge}
                                </span>
                              ) : null}
                              {c.partnerCity ? (
                                <span className="text-xs font-normal text-slate-500 dark:text-slate-400">
                                  {" "}
                                  · {c.partnerCity}
                                </span>
                              ) : null}
                            </div>
                            <div className="shrink-0 text-[11px] text-slate-400 dark:text-slate-500">
                              {c.lastAt}
                            </div>
                          </div>
                          <div className="truncate text-[11px] text-slate-600 dark:text-slate-300">
                            {c.lastMessage}
                          </div>
                          <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                            {typeof c.compatibility === "number" && (
                              <div className="inline-flex items-center gap-1 rounded-full bg-slate-100 px-2 py-0.5 text-[10px] text-slate-700 dark:bg-slate-800 dark:text-slate-200">
                                <Star className="h-3 w-3 text-rose-500" />
                                <span>
                                  {Math.round((c.compatibility || 0) * 100)}%
                                </span>
                              </div>
                            )}
                            {c.unread ? (
                              <span className="ml-auto inline-flex rounded-full bg-rose-600 px-2 py-0.5 text-[10px] font-semibold text-white">
                                {c.unread}
                              </span>
                            ) : null}
                          </div>
                        </div>
                      </button>

                      {/* Right side: kebab menu (only show on active row) */}
                      {isActive && (
                        <div className="relative">
                          {/* 3-dot trigger */}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setMenuFor(isMenuOpen ? null : c.id);
                            }}
                            className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700 dark:text-slate-500 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                            title="More options"
                          >
                            <MoreVertical className="h-4 w-4" />
                          </button>

                          {/* Dropdown menu */}
                          {isMenuOpen && (
                            <div className="absolute right-0 mt-1 w-36 rounded-2xl border border-slate-200 bg-white/95 text-xs text-slate-700 shadow-lg dark:border-slate-700 dark:bg-slate-900/95 dark:text-slate-200">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  endChat(c.id);
                                }}
                                className="w-full rounded-2xl px-4 py-2 text-left text-rose-600 hover:bg-rose-50 dark:text-rose-300 dark:hover:bg-rose-950/40"
                              >
                                End chat
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}

                {filtered.length === 0 && (
                  <div className="flex flex-col items-center px-4 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
                    <MessageSquareHeart className="mb-2 h-6 w-6 text-indigo-500 dark:text-indigo-300" />
                    <div className="text-sm text-slate-700 dark:text-slate-200">
                      No conversations yet.
                    </div>
                    <div className="mt-3">
                      <button
                        onClick={getNewMatch}
                        disabled={matchLoading || !canMatch}
                        className={
                          "inline-flex items-center gap-2 rounded-full px-3 py-2 text-xs font-medium " +
                          (matchLoading
                            ? "bg-slate-200 text-slate-500 cursor-wait dark:bg-slate-800 dark:text-slate-400"
                            : !canMatch
                            ? "bg-slate-200 text-slate-500 cursor-not-allowed dark:bg-slate-800 dark:text-slate-500"
                            : "bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 text-white shadow-sm hover:brightness-110")
                        }
                      >
                        {matchLoading ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Plus className="h-3.5 w-3.5" />
                        )}
                        <span>Find my first match</span>
                      </button>
                    </div>
                    <div className="mt-2 w-full max-w-xs">
                      <MatchErrorActions
                        matchError={matchError}
                        verified={verified}
                        assessmentIncomplete={assessmentIncomplete}
                        align="center"
                      />
                    </div>
                  </div>
                )}
              </div>
            </aside>

            {/* Middle/right: Active thread */}
            <section className="flex min-h-[70vh] flex-col rounded-3xl border border-slate-200 bg-white/80 shadow-sm shadow-slate-200/60 backdrop-blur dark:border-slate-700 dark:bg-slate-900/80 dark:shadow-black/30">
              {!active ? (
                <div className="flex-1 p-8">
                  <div className="grid h-full place-items-center">
                    {hasAnyConvos ? (
                      <div className="w-full max-w-sm text-center">
                        <MessageSquareHeart className="mx-auto h-10 w-10 text-indigo-500 dark:text-indigo-300" />
                        <p className="mt-3 text-sm text-slate-700 dark:text-slate-200">
                          Select a conversation on the left to start chatting.
                        </p>

                        <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50/80 p-4 text-left text-xs text-slate-700 dark:border-slate-700 dark:bg-slate-900/70 dark:text-slate-200">
                          <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-indigo-500 dark:text-indigo-300" />
                              {canMatch ? (
                                <span>You can request a new match now.</span>
                              ) : nextEligibleAt ? (
                                <span>Next curated match in {countdown}.</span>
                              ) : (
                                <span>Matching is currently unavailable.</span>
                              )}
                            </div>
                            <MatchErrorActions
                              matchError={matchError}
                              verified={verified}
                              assessmentIncomplete={assessmentIncomplete}
                              align="left"
                            />
                          </div>

                          <button
                            onClick={getNewMatch}
                            disabled={matchLoading || !canMatch}
                            className={
                              "mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full px-3 py-2 text-xs font-medium " +
                              (matchLoading
                                ? "bg-slate-200 text-slate-500 cursor-wait dark:bg-slate-800 dark:text-slate-400"
                                : !canMatch
                                ? "bg-slate-200 text-slate-500 cursor-not-allowed dark:bg-slate-800 dark:text-slate-500"
                                : "bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 text-white shadow-sm hover:brightness-110")
                            }
                          >
                            {matchLoading ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Plus className="h-3.5 w-3.5" />
                            )}
                            <span>New match</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center text-sm text-slate-600 dark:text-slate-300">
                        <MessageSquareHeart className="mx-auto h-10 w-10 text-indigo-500 dark:text-indigo-300" />
                        <p className="mt-3">
                          No conversations yet. Try creating your first match.
                        </p>
                        <div className="mt-4 w-full max-w-xs mx-auto">
                          <MatchErrorActions
                            matchError={matchError}
                            verified={verified}
                            assessmentIncomplete={assessmentIncomplete}
                            align="center"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  {/* Thread header */}
                  <div className="flex items-center justify-between border-b border-slate-200 bg-white/80 px-4 py-3 text-sm dark:border-slate-700 dark:bg-slate-900/80">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-900 dark:text-slate-50">
                          {active?.partnerName}
                        </span>
                        {typeof active?.compatibility === "number" && (
                          <span className="rounded-full bg-rose-50 px-2 py-0.5 text-[11px] font-medium text-rose-700 dark:bg-rose-950/40 dark:text-rose-200">
                            {Math.round((active.compatibility || 0) * 100)}% match
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        Daily match · {active?.partnerCity || "Unknown"}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <Link
                        to="/profile"
                        className="underline decoration-slate-300 underline-offset-4 hover:text-indigo-600 dark:decoration-slate-600 dark:hover:text-indigo-300"
                      >
                        Adjust preferences
                      </Link>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </div>
                  </div>

                  {/* Thread body */}
                  <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
                    {thread.map((m) => (
                      <motion.div
                        key={m.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${
                          m.role === "me" ? "justify-end" : "justify-start"
                        }`}
                      >
                        <div
                          className={`max-w-[78%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm ${
                            m.role === "me"
                              ? "bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 text-white"
                              : "bg-slate-100/90 text-slate-900 dark:bg-slate-800/80 dark:text-slate-50"
                          }`}
                        >
                          {m.text}
                        </div>
                      </motion.div>
                    ))}
                    <div ref={bottomRef} />
                  </div>

                  {/* Composer */}
                  <form
                    className="flex items-center gap-3 border-t border-slate-200 bg-white/80 px-4 py-3 dark:border-slate-700 dark:bg-slate-900/80"
                    onSubmit={(e) => {
                      e.preventDefault();
                      send();
                    }}
                  >
                    <input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onFocus={() =>
                        activeId &&
                        (markReadWS(), api.markRead(activeId).catch(() => {}))
                      }
                      placeholder="Write a message…"
                      className="flex-1 rounded-2xl border border-slate-200 bg-white px-4 py-2.5 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50 dark:placeholder:text-slate-500 dark:focus:border-indigo-400 dark:focus:ring-indigo-900/40"
                      onKeyDown={() => setTyping(true)}
                      onBlur={() => setTyping(false)}
                    />
                    <button
                      type="submit"
                      disabled={sending}
                      className="inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-500 via-violet-500 to-rose-500 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:brightness-110 disabled:opacity-60"
                    >
                      {sending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <SendHorizontal className="h-4 w-4" />
                      )}
                      Send
                    </button>
                  </form>
                  <div className="px-4 pb-3 text-[11px] text-slate-400 dark:text-slate-500">
                    WS status: {wsStatus}
                  </div>
                </>
              )}
            </section>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 py-4 text-[11px] text-slate-500 dark:border-slate-800 dark:text-slate-400">
          <div className="flex flex-col items-center justify-between gap-3 sm:flex-row">
            <div className="flex items-center gap-2">
              <span>© {new Date().getFullYear()} LikeMinded.</span>
              <span className="hidden sm:inline">
                Built for people who want clarity before connection.
              </span>
            </div>
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Home
              </Link>
              <Link
                to="/chatbot"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Assessment
              </Link>
              <Link
                to="/profile"
                className="hover:text-indigo-600 dark:hover:text-indigo-300"
              >
                Profile
              </Link>
              <AuthStatus />
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

/* ---------------- Helpers ---------------- */
function useNow(intervalMs = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

function msToClock(ms: number) {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}
