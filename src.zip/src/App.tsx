import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import ChatbotPage from "./pages/ChatbotPage";
import ConversationsPage from "./pages/ConversationsPage";
import ProfilePage from "./pages/ProfilePage";
import LoginPage from "./pages/LoginPage";
import AuthCallback from "./pages/AuthCallback";
import { AuthProvider, useAuth } from "./auth/AuthProvider";
import ProtectedRoute from "./auth/ProtectedRoute";
import AdminPage from "./pages/Admin";
import { ThemeProvider } from "./theme/ThemeProvider";

/**
 * When the user is authenticated and visits "/", redirect to /conversations.
 * Otherwise show the public landing page.
 */
function LandingOrRedirect() {
  const { user, loading } = useAuth?.() ?? { user: null, loading: false };

  // While auth state is loading, render nothing (or a minimal placeholder).
  if (loading) {
    return null;
  }

  if (user) {
    return <Navigate to="/conversations" replace />;
  }

  return <LandingPage />;
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <AuthProvider>
          {/* NOTE: no dark: classes here so other pages look exactly as before */}
          <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-50 transition-colors duration-300">
            <Routes>
              <Route path="/" element={<LandingOrRedirect />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/auth/callback" element={<AuthCallback />} />

              {/* Protected area */}
              <Route element={<ProtectedRoute />}>
                <Route path="/chatbot" element={<ChatbotPage />} />
                <Route path="/conversations" element={<ConversationsPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/admin" element={<AdminPage />} />
              </Route>
            </Routes>
          </div>
        </AuthProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
