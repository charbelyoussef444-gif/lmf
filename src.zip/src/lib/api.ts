// src/lib/api.ts
import { supabase } from "./supabaseClient";

const API = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

/** Chatbot response type (matches backend: updated_traits) */
export type ChatbotResponse = {
  reply: string;
  phase?: "self" | "pref" | "done";
  updated_traits?: Record<string, number>; // keys are trait_id as strings, e.g. "5"
  // keep this optional for future, but we don't rely on it:
  attributes?: Record<string, number>;
  progress?: {
    self_filled?: number;
    self_total?: number;
    pref_filled?: number;
    pref_total?: number;
  };
};

/** Chatbot history type (matches /chatbot/history) */
export type ChatbotHistoryResponse = {
  messages: Array<{
    role: "assistant" | "user";
    content: string;
    ts: string;
  }>;
  phase: "self" | "pref" | "done";
  progress: {
    self_filled: number;
    self_total: number;
    pref_filled?: number;
    pref_total?: number;
  };
};

/** Personality traits from DB + per-user score */
export type Trait = {
  id: number;
  name: string;
  description: string | null;
  score?: number | null; // current user_personality.score, if any
};

/* ---------- Types ---------- */
export type Conversation = {
  id: string;
  partnerName: string;
  partnerAge?: number;
  partnerCity?: string;
  lastMessage?: string;
  lastAt?: string; // "10m", "Yesterday", etc.
  compatibility?: number | null;
  unread?: number;
};

export type Msg = {
  id: string;
  role: "me" | "them";
  text?: string;
  ts: number; // seconds since epoch
};

/** Match API response types */
export type MatchIneligible = {
  status: "ineligible";
  user_id: string;
  reason: string;
};

export type MatchNoMatch = {
  status: "no_match";
  user_id: string;
};

export type MatchSuccess = {
  status: "matched";
  user_a_id: string;
  user_b_id: string;
  score: number;
  conversation_id: string;
};

export type MatchStatus = {
  eligible: boolean;
  reason: string | null;
  next_eligible_ts_utc: string | null; // ISO timestamp or null
};

export type MatchResponse = MatchIneligible | MatchNoMatch | MatchSuccess;

/** Profile returned by /me, /me/weights, /me/preferences */
export type ProfileResponse = {
  id: string;
  full_name: string;
  gender?: string | null;
  age?: number | null;
  location?: string | null;
  personality_weight: number;
  interests_weight: number;
  verified: boolean;
  admin?: boolean;
  is_admin?: boolean;

  // match preferences (backend: preferred_min_age, preferred_max_age, gender_pref)
  preferred_min_age?: number | null;
  preferred_max_age?: number | null;
  preferred_gender?: "women" | "men" | "everyone" | null;
};

/* ---------- Core fetch with Supabase bearer ---------- */
async function getToken() {
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token ?? null;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = await getToken();
  const headers = new Headers(init.headers);

  // Only set JSON for non-FormData
  const isFormData =
    typeof FormData !== "undefined" && init.body instanceof FormData;
  if (!isFormData && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const res = await fetch(`${API}${path}`, { ...init, headers });

  if (res.status === 401) {
    const msg = await res.text().catch(() => "");
    throw new Error(`Unauthorized${msg ? `: ${msg}` : ""}`);
  }

  if (!res.ok) {
    const msg = await res.text().catch(() => "");
    throw new Error(`${res.status} ${res.statusText}${msg ? `: ${msg}` : ""}`);
  }

  const ct = res.headers.get("content-type") || "";
  return ct.includes("application/json")
    ? ((await res.json()) as T)
    : ((await res.text()) as unknown as T);
}

/* ---------- single in-flight guard for chatbot ---------- */
let chatbotMessageInFlight: Promise<ChatbotResponse> | null = null;

/* ---------- API surface (matches your FastAPI backend) ---------- */
export const api = {
  // Health
  health: () => request<{ ok: boolean }>("/healthz"),

  // Profile / weights / interests
  me: () => request<ProfileResponse>("/me"),

  myInterests: () =>
    request<Array<{ id: number; name: string; category?: string | null }>>(
      "/me/interests"
    ),

  // NEW: all interests in the system (for profile picker)
  allInterests: () =>
    request<Array<{ id: number; name: string; category?: string | null }>>(
      "/me/interests/all"
    ),

  putInterests: (names: string[]) =>
    request<Array<{ id: number; name: string; category?: string | null }>>(
      "/me/interests",
      {
        method: "PUT",
        body: JSON.stringify(names.map((n) => ({ name: n }))),
      }
    ),

  putWeights: (personality_weight: number, interests_weight: number) =>
    request<ProfileResponse>("/me/weights", {
      method: "PUT",
      body: JSON.stringify({ personality_weight, interests_weight }),
    }),

  // NEW: update match preferences (age range + gender preference)
  updateMatchPreferences: (payload: {
    preferred_min_age: number | null;
    preferred_max_age: number | null;
    preferred_gender: "women" | "men" | "everyone" | null;
  }) =>
    request<ProfileResponse>("/me/preferences", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),

  // Photos
  myPhotos: () => request<string[]>("/me/photos"),

  uploadGalleryPhoto: (file: File, position: 1 | 2 | 3) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("position", String(position));
    return request<{ ok: true; photo_id: string; path: string }>(
      "/me/photos/gallery",
      {
        method: "POST",
        body: fd,
      }
    );
  },

  uploadVerificationId: (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    return request<{ ok: true; photo_id: string; path: string }>(
      "/me/photos/verification",
      {
        method: "POST",
        body: fd,
      }
    );
  },

  // KYC
  meKycStatus: () =>
    request<{
      status: "unverified" | "pending" | "verified";
      reasons: Array<{ reason: string; created_at: string }>;
    }>("/me/kyc/status"),

  meKycUpload: (files: File[]) => {
    const fd = new FormData();
    files.forEach((f) => fd.append("files", f));
    return request<{ ok: boolean; count: number }>("/me/kyc/upload", {
      method: "POST",
      body: fd,
    });
  },

  meKycCancel: () =>
    request<{ ok: boolean }>("/me/kyc/cancel", { method: "DELETE" }),

  // Conversations & messages
  conversations: () => request<Conversation[]>("/conversations"),

  thread: (cid: string) => request<Msg[]>(`/conversations/${cid}/messages`),

  sendMessage: (cid: string, text: string) =>
    request<Msg>(`/conversations/${cid}/messages`, {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  markRead: (cid: string) =>
    request<null>(`/conversations/${cid}/read`, { method: "POST" }),

  endConversation: (cid: string) =>
    request<null>(`/conversations/${cid}/end`, { method: "POST" }),

  // Matching
  matchStatus: () => request<MatchStatus>("/matching/status"),

  match: () =>
    request<MatchResponse>("/matching/generate", {
      method: "POST",
    }),

  // Chatbot
  chatbotMessage: (message: string) => {
    // Prevent multiple concurrent POSTs to /chatbot/message.
    if (chatbotMessageInFlight) {
      return chatbotMessageInFlight;
    }

    chatbotMessageInFlight = request<ChatbotResponse>("/chatbot/message", {
      method: "POST",
      body: JSON.stringify({ message }),
    }).finally(() => {
      chatbotMessageInFlight = null;
    });

    return chatbotMessageInFlight;
  },

  chatbotHistory: () =>
    request<ChatbotHistoryResponse>("/chatbot/history"),

  listPersonalityTraits: () => request<Trait[]>("/traits"),

  /* ---------- Admin ---------- */
  adminListPendingKyc: () =>
    request<
      Array<{
        user_id: string;
        created_at: string;
        full_name?: string | null;
        age?: number | null;
      }>
    >("/admin/kyc/pending"),

  adminKycImages: (userId: string) =>
    request<{
      user_id: string;
      full_name?: string | null;
      age?: number | null;
      images: Array<{ name: string; url: string }>;
    }>(`/admin/kyc/${userId}/images`),

  adminApproveKyc: (userId: string) =>
    request<{ ok: boolean }>(`/admin/kyc/${userId}/approve`, {
      method: "POST",
    }),

  adminRejectKyc: (userId: string, reason: string) =>
    request<{ ok: boolean }>(`/admin/kyc/${userId}/reject`, {
      method: "POST",
      body: JSON.stringify({ reason }),
    }),

  adminListUsers: (q?: string, limit = 50, offset = 0) => {
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (limit) params.set("limit", String(limit));
    if (offset) params.set("offset", String(offset));
    const qs = params.toString();
    return request<
      Array<{
        id: string;
        full_name?: string | null;
        email?: string | null;
        verified?: boolean;
        banned?: boolean;
        admin?: boolean; // accept either naming
        is_admin?: boolean; // accept either naming
        created_at?: string;
      }>
    >(`/admin/users${qs ? `?${qs}` : ""}`);
  },

  adminBan: (userId: string) =>
    request<{ ok: boolean }>(`/admin/users/${userId}/ban`, {
      method: "POST",
    }),

  adminUnban: (userId: string) =>
    request<{ ok: boolean }>(`/admin/users/${userId}/unban`, {
      method: "POST",
    }),

  adminPromote: (userId: string) =>
    request<{ ok: boolean }>(`/admin/users/${userId}/promote`, {
      method: "POST",
    }),

  adminDemote: (userId: string) =>
    request<{ ok: boolean }>(`/admin/users/${userId}/demote`, {
      method: "POST",
    }),

  // Onboarding: age, location, match preferences in one shot
  completeOnboarding: (payload: {
    age: number;
    location: string | null;
    gender: "woman" | "man" | "nonbinary" | null;
    preferred_min_age: number | null;
    preferred_max_age: number | null;
    preferred_gender: "women" | "men" | "everyone" | null | null;
  }) =>
    request<ProfileResponse>("/me/onboarding", {
      method: "PUT",
      body: JSON.stringify(payload),
    }),
};
